#include "GameEngine.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <algorithm>
#include <random>
#include <conio.h>
#include <chrono>
#include <thread>
using namespace std;
//consructor,basically setting up our games starter kit
GameEngine::GameEngine(){
    //nobody playing yet
    currentPlayer = nullptr;
    //green light is go
    signal = true;
    //havent answered anything yet
    questionsAnswered = 0;
    //how many questions in a full game
    totalQuestions = 10;
    //how long each ligh signal lasts
    signalDuration = 3;
    //no game is active right now
    gameRunning = false;
    //load u in our dsa question bank
    loadQuestions();
    //make random numbers actually random
    srand(time(0));
}
//destructor-cleaning up he mess when we are done
GameEngine::~GameEngine(){
    //free all the memory we allocated for questions
    for(auto q:allQuestions){
        //goodbye question jobs
        delete q;
    }
    //free all player memory too
    for(auto& p:players){
        //each player gets its own farewell
        delete p.second;
    }
}
//main game loop-keeps running until player quits
void GameEngine::run() {
    while(true) {
            //show menu handle choices
        showMainMenu();
    }
}
//load up our DSA questions
void GameEngine::loadQuestions() {
    //Ah binary search the classic "divide and conquer"algorithm
    //but seriously its O(log n),not O(n)
    allQuestions.push_back(new Question(
        "What is the time complexity of binary search?",
        {"O(n)", "O(log n)", "O(n log n)", "O(1)"},
        1, 15)
);

    //LIFO =stack
    //FIFO= queue
allQuestions.push_back(new Question(
        "Which data structure uses LIFO principle?",
        {"Queue", "Stack", "Linked List", "Tree"},
        1, 15)//answer  is (O(log n))
);
    //DFS vs BFS-the eernl graph traversal debate
    allQuestions.push_back(new Question(
        "What does DFS stand for in graph traversal?",
        {"Depth First Search", "Breadth First Search",
         "Dynamic First Search", "Data First Search"},
        0, 15)//dfs answer
);
    //queues:the"take a number and wait"of data srucures
    allQuestions.push_back(new Question(
    "What is the main operation of a queue data structure?",
    {"enqueue and dequeue", "push and pop", "insert and delete", "add and remove"},
    0, 15) // enqueue/dequeue
);
    //quick sort can be O(n�) in worst case
    //usally when he pivot choice is terrible
    allQuestions.push_back(new Question(
        "What is the worst-case time complexity of quicksort?",
        {"O(n log n)", "O(n^2)", "O(log n)", "O(n)"},
        1, 15)// O(n�)
);
//in order  traversal gives you a sorted output in binary search trees
//pre order is for copying,post order for deleting
allQuestions.push_back(new Question(
    "To print tree elements in sorted order, which traversal should you use?",
    {"In-order traversal", "Pre-order traversal", "Post-order traversal", "Level-order traversal"},
    0, 15) // In-order
);
//leaves:the endpoints of the tree,where daa goes o reire
allQuestions.push_back(new Question(
    "A tree node with no children is called what?",
    {"Leaf node", "Root node", "Parent node", "Internal node"},
    0, 15)// Leaf node
);
//yes,Stack uses LIFO too-same as question 2 but phrased differently
// Repetition is the mother of learning, I guess?
allQuestions.push_back(new Question(
    "Stack follows which principle for its data operations?",
    {"LIFO (Last In First Out)", "FIFO (First In First Out)", "FILO (First In Last Out)", "Random Access"},
    0, 15)// LIFO
);
//arrays,simple,contiguous meemory.not fancy ,but gets the ob done
allQuestions.push_back(new Question(
    "What is the simplest way to store multiple items of same type?",
    {"Array", "Linked List", "Tree", "Stack"},
    0, 15)// Array
);
//linked lists:ech clue points to the next
allQuestions.push_back(new Question(
    "Which data structure allows you to connect nodes with links?",
    {"Linked List", "Array", "Stack", "Queue"},
    0, 15) // Linked List
);
//shuffle the questionsso players dont memorize he order
//using proper random device for better shufffling
 // Get real randomness from the system
random_device rand;
    // Mersenne Twister engine - fancy random
    mt19937 g(rand());
      //mix them up
    shuffle(allQuestions.begin(), allQuestions.end(), g);
}
//show the main menu-the gateway to our game
void GameEngine::showMainMenu() {
    // Fresh slate!
    ConsoleInterface::clearScreen();
    // Some breathing room at the top
    cout << "\n\n\n\n";
    //fancy title in green
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("====================================");
    ConsoleInterface::centerText("    SQUID GAME DSA QUIZ    ");
    ConsoleInterface::centerText("====================================\n\n");
    // Menu options in blue
    ConsoleInterface::setBlue();
    cout << endl;
    ConsoleInterface::centerText("1. Register New Player");
    ConsoleInterface::centerText("2. Login");
    ConsoleInterface::centerText("3. View Leaderboard");
    ConsoleInterface::centerText("4. Exit\n\n");
    //prompt in yellow
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("Select option: ");

    ConsoleInterface::setWhite();
    //get single key press no enter needed
    char choice = _getch();
    // Handle the user's choice
    switch(choice) {
        case '1':
            //lets make a new player
            registerPlayer();
            break;
        case '2':
            //welcome back!
            loginPlayer();
            break;
        case '3':
            // See who's on top
            showLeaderboard();
            break;
        case '4':
            exit(0);// Bye bye!
    }
}
//register a new player cuz everyone needs aa user name
void GameEngine::registerPlayer() {
    ConsoleInterface::clearScreen();
    cout << "\n\n\n";

    ConsoleInterface::setBlue();
    ConsoleInterface::centerText("=============================");
    ConsoleInterface::centerText("     REGISTER PLAYER     ");
    ConsoleInterface::centerText("=============================\n\n");

    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("Enter username: ");

    ConsoleInterface::setWhite();
    string name;
    //get the user name
    cin >> name;

    // Check if this username is already taken
    if(players.find(name) != players.end()) {
        ConsoleInterface::setRed();
        ConsoleInterface::centerText("\nPlayer already exists!");
        ConsoleInterface::setWhite();
        //show messages for 2 seconds
        ConsoleInterface::sleep(2000);
        //back to menu we go
        return;
    }
     // Create new player and add to our player database
    Player* newPlayer = new Player(name);
    players[name] = newPlayer;
      // Success!
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("\nRegistration successful!");
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("Press any key to continue...");
    ConsoleInterface::setWhite();
    //wait for any key press
    _getch();
}
// Login existing player
void GameEngine::loginPlayer() {
    ConsoleInterface::clearScreen();
    cout << "\n\n\n";

    ConsoleInterface::setBlue();
    ConsoleInterface::centerText("=====================");
    ConsoleInterface::centerText("     PLAYER LOGIN     ");
    ConsoleInterface::centerText("=====================\n\n");

    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("Enter username: ");

    ConsoleInterface::setWhite();
    string name;
    cin >> name;
    //check if player exists
    if(players.find(name) == players.end()) {
        ConsoleInterface::setRed();
        ConsoleInterface::centerText("\nPlayer not found! Register first.");
        ConsoleInterface::setWhite();
        ConsoleInterface::sleep(2000);
        return;
    }
    //set this player as he current payer
    currentPlayer = players[name];
    // Welcome them!
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("\nLogin successful! Welcome " + name + "!");
    ConsoleInterface::sleep(1000);
   // Show the game menu now that they're logged in
    showGameMenu();
}
// Show the game menu after login
void GameEngine::showGameMenu() {
    while(true) {
        ConsoleInterface::clearScreen();
        cout << "\n\n\n";
        // Show who's playing
        ConsoleInterface::setBlue();
        ConsoleInterface::centerText("=============================");
        ConsoleInterface::centerText("     PLAYER: " + currentPlayer->getName() + "     ");
        ConsoleInterface::centerText("=============================\n\n");
        // Show their high score
        ConsoleInterface::setGreen();
        ConsoleInterface::centerText("High Score: " + to_string(currentPlayer->getHighScore()) + "\n\n");
        // Game menu options
        ConsoleInterface::setBlue();
        ConsoleInterface::centerText("1. Start New Game");
        ConsoleInterface::centerText("2. How to Play");
        ConsoleInterface::centerText("3. Logout\n\n");

        ConsoleInterface::setYellow();
        ConsoleInterface::centerText("Select option: ");

        ConsoleInterface::setWhite();
        char choice = _getch();

        switch(choice) {
            //let the games begin!
            case '1': startGame(); break;
            // read the rules
            case '2': showInstructions(); break;
            //back to the main menu
            case '3': return;
        }
    }
}
//show game instructions-because nobody reads manual yntil hey lose
void GameEngine::showInstructions() {
    ConsoleInterface::clearScreen();
    cout << "\n\n\n";

    ConsoleInterface::setBlue();
    ConsoleInterface::centerText("=============================");
    ConsoleInterface::centerText("     HOW TO PLAY     ");
    ConsoleInterface::centerText("=============================\n\n");
    //the rules pay attenion
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("RED LIGHT / GREEN LIGHT RULES:");
    ConsoleInterface::centerText("1. Answer DSA questions correctly");
    ConsoleInterface::centerText("2. GREEN LIGHT = You can answer");
    // RED LIGHT warning in, well, red
    ConsoleInterface::setRed();
    ConsoleInterface::centerText("3. RED LIGHT = FREEZE! Don't press ANY key");
    // How you can get eliminated
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("4. Elimination conditions:");
    ConsoleInterface::centerText("   - Wrong answer");
    ConsoleInterface::centerText("   - Press key during RED light");
    ConsoleInterface::centerText("   - Time runs out\n\n");
    //scoring system
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("SCORING:");
    ConsoleInterface::centerText("- Correct answer: +10 points");
    ConsoleInterface::centerText("- Complete all questions: Bonus 50 points");
    ConsoleInterface::centerText("- Elimination: Game over\n\n");

    ConsoleInterface::setBlue();
    ConsoleInterface::centerText("Press any key to continue...");
    ConsoleInterface::setWhite();
    _getch();
}
//show the leaderboard-whos the dsa champion
void GameEngine::showLeaderboard() {
    ConsoleInterface::clearScreen();
    cout << "\n\n\n";

    ConsoleInterface::setBlue();
    ConsoleInterface::centerText("=============================");
    ConsoleInterface::centerText("     LEADERBOARD     ");
    ConsoleInterface::centerText("=============================\n\n");
    // Get all players and their scores
    vector<pair<string, int>> leaderboard;
    for(auto& p : players) {
        leaderboard.push_back({p.first, p.second->getHighScore()});
    }
    //sort by score highest first
    sort(leaderboard.begin(), leaderboard.end(),
         [](auto& a, auto& b) { return a.second > b.second; });
    //print fancy header
    ConsoleInterface::setGreen();
    string header = "Rank  Player            Score";
    int hSpaces = (50 - header.length()) / 2;
    if(hSpaces > 0) cout << string(hSpaces, ' ');
    cout << header << endl;

    string separator = "----  -------           -----";
    int sSpaces = (50 - separator.length()) / 2;
    if(sSpaces > 0) cout << string(sSpaces, ' ');
    cout << separator << "\n\n";
    //show top 10 players
    ConsoleInterface::setWhite();
    for(size_t i = 0; i < min((size_t)10, leaderboard.size()); i++) {
        string row = to_string(i+1) + ".    " + leaderboard[i].first;
        row += string(15 - leaderboard[i].first.length(), ' ');
        row += to_string(leaderboard[i].second);
        // Center the row
        int rSpaces = (50 - row.length()) / 2;
        if(rSpaces > 0) cout << string(rSpaces, ' ');
        cout << row << "\n";
    }

    cout << "\n\n";
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("Press any key to continue...");
    ConsoleInterface::setWhite();
    _getch();
}
//start a new game-reset everyhing and prepare
void GameEngine::startGame() {
    //reset players current game state
    currentPlayer->reset();
    questionsAnswered = 0;
    gameRunning = true;
    // Clear any old questions from the queue
    while(!questionQueue.empty()) questionQueue.pop();
    // Shuffle questions again for this game
    random_device rd;
    mt19937 g(rd());
    shuffle(allQuestions.begin(), allQuestions.end(), g);
    //for add quesions o he queue
    for(size_t i = 0; i < totalQuestions && i < allQuestions.size(); i++) {
        questionQueue.push(allQuestions[i]);
    }
     //play rounds until game ends or questions run out
    while(gameRunning && !questionQueue.empty()) {
        playRound();
    }

    if(!currentPlayer->isEliminated()) {
        showWinScreen();
    }
}
//play 1 round of the game
void GameEngine::playRound() {
    if(questionQueue.empty())
        return;
    //get the next question
    Question* currentQ = questionQueue.front();
    // Set up light signals
    //random duration 3-6 seconds
    signalDuration = 3 + rand() % 4;
    //randomly start with red or green
    signal = (rand() % 2 == 0);
    //when this signal sarted
    signalStart = time(0);
    // Actually, let's always start with green
    // Always start with GREEN light
    signal = true;
    //reset timer
    signalStart = time(0);
    //has he player answered yet
    bool answered = false;
    // Start timing
    auto questionStartTime = chrono::steady_clock::now();
    // Get time limit for this question
    const int TIME_LIMIT = currentQ->getTimeLimit();
    //keep going until players answers or end game
    while(!answered && gameRunning) {
        ConsoleInterface::clearScreen();
        //calculate the time left
        auto currentTime = chrono::steady_clock::now();
        auto elapsed = chrono::duration_cast<chrono::seconds>(currentTime - questionStartTime).count();
        int timeLeft = TIME_LIMIT - elapsed;
        //times up
        if (timeLeft <= 0) {
            eliminate("Time's up! You didn't answer in " + to_string(TIME_LIMIT) + " seconds!");
            return;
        }
        //should we change the light signal
        if(difftime(time(0), signalStart) > signalDuration) {
            //toggle between red and green
            signal = !signal;
            //reset signal timer
            signalStart = time(0);
            //new random duration 2-4 seconds
            signalDuration = 2 + rand() % 3;
        }
        //display game info at top
        ConsoleInterface::setGreen();
        ConsoleInterface::centerText("Player: " + currentPlayer->getName() +
                     " | Score: " + to_string(currentPlayer->getScore()) +
                     " | Q: " + to_string(questionsAnswered + 1) +
                     "/" + to_string(totalQuestions));
        //show time left with color coding
        cout << " | Time Left: ";
        if (timeLeft <= 5) {
            //panic mode
            ConsoleInterface::setRed();
        } else if (timeLeft <= 10) {
            //getting close
            ConsoleInterface::setYellow();
        } else {
            //plenty of time
            ConsoleInterface::setGreen();
        }
        cout << timeLeft << "s";

        ConsoleInterface::setWhite();
        cout << "\n\n";
        // Show current signal
        if(signal) {
            // GREEN LIGHT - GO!
            ConsoleInterface::setGreen();
            ConsoleInterface::centerText("=====================");
            ConsoleInterface::centerText("    GREEN LIGHT    ");
            ConsoleInterface::centerText("=====================");
            cout << endl;
            ConsoleInterface::centerText("ANSWER NOW!");
        } else {
            ConsoleInterface::setRed();
            ConsoleInterface::centerText("=====================");
            ConsoleInterface::centerText("    RED LIGHT    ");
            ConsoleInterface::centerText("=====================");
            cout << endl;
            ConsoleInterface::centerText("FREEZE! DON'T MOVE!");
        }

        cout << "\n\n";
        //display the question
        ConsoleInterface::setWhite();
        ConsoleInterface::centerText(currentQ->getQuestion());
        cout << endl;

        vector<string> options = currentQ->getOptions();
        for(size_t i = 0; i < options.size(); i++) {
            ConsoleInterface::centerText(to_string(i+1) + ". " + options[i]);
        }

        cout << "\n";
        //check if player pressed a key
        if(_kbhit()) {
            //they press during red light
            if(!signal) {
                //clear the key press
                _getch();
                eliminate("Moved during RED light!");
                return;
            }
             //GREEN light - they can answer
            char ch = _getch();
            if(ch >= '1' && ch <= '0' + options.size()) {
                //convert '1' to 0, '2' to 1, etc.
                int answer = ch - '1';
                 //check if answer is correct
                if(currentQ->checkAnswer(answer)) {
                    ConsoleInterface::setGreen();
                    ConsoleInterface::centerText("CORRECT! +10 points");
                    //happy heap
                    ConsoleInterface::beep(800, 200);
                    // Pause to celebrate
                    ConsoleInterface::sleep(1000);
                    //update score and move to the next question
                    currentPlayer->addScore(10);
                    questionQueue.pop();
                    questionsAnswered++;
                    answered = true;
                } else {
                    //wrong answer = elimination
                    eliminate("Wrong answer!");
                    return;
                }
                //esc key
            } else if(ch == 27) {
                //quit game
                gameRunning = false;
                return;
            }
        }
        //small delay to prevent CPU hogging
        ConsoleInterface::sleep(100);
    }
}
//eliminate the player
void GameEngine::eliminate(const string& reason) {
    //mark player as eiminated
    currentPlayer->eliminate();
    //game over
    gameRunning = false;
    //record this eleimination for recent eliminations displaa
    eliminations.push({currentPlayer->getName(), reason});
    //show elimination screen
    ConsoleInterface::clearScreen();
    cout << "\n\n\n";
    //big scary elimination message
    ConsoleInterface::setRed();
    ConsoleInterface::centerText("=====================");
    ConsoleInterface::centerText("    ELIMINATED!    ");
    ConsoleInterface::centerText("=====================");
    cout << "\n\n";
     //show player info
    ConsoleInterface::setWhite();
    ConsoleInterface::centerText("Player: " + currentPlayer->getName());
    ConsoleInterface::centerText("Score: " + to_string(currentPlayer->getScore()));
    //color code the reason if its thre RED light related
    if(reason.find("RED") != string::npos || reason.find("red") != string::npos) {
        ConsoleInterface::setRed();
    } else {
        ConsoleInterface::setWhite();
    }
    ConsoleInterface::centerText("Reason: " + reason);
    cout << "\n\n";
    //sow recent eliminations
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("Recent Eliminations:");
    ConsoleInterface::centerText("--------------------\n");

    ConsoleInterface::setWhite();
    stack<pair<string, string>> temp = eliminations;
    int count = 0;
    while(!temp.empty() && count < 5) {
        ConsoleInterface::centerText(temp.top().first + " - " + temp.top().second);
        temp.pop();
        count++;
    }
    //sad elimintion sound effect
    ConsoleInterface::beep(300, 300);
    ConsoleInterface::sleep(200);
    ConsoleInterface::beep(200, 400);

    cout << "\n\n";
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("Press any key to continue...");
    ConsoleInterface::setWhite();
    _getch();
}
//show victory screen,,they survived all questions!
void GameEngine::showWinScreen() {
    ConsoleInterface::clearScreen();
    cout << "\n\n\n";
    //celebration time!
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("=====================");
    ConsoleInterface::centerText("    VICTORY!    ");
    ConsoleInterface::centerText("=====================");
    cout << "\n\n";

    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("CONGRATULATIONS " + currentPlayer->getName() + "!");
    cout << "\n\n";

    ConsoleInterface::setBlue();
    ConsoleInterface::centerText("You answered all DSA questions correctly!");
    cout << "\n\n";
     //give bonus points for completing all questions
    int bonus = 50;
    currentPlayer->addScore(bonus);
      //show final score
    ConsoleInterface::setWhite();
    ConsoleInterface::centerText("Final Score: " + to_string(currentPlayer->getScore()));
    ConsoleInterface::centerText("Bonus: +" + to_string(bonus) + " points");
    ConsoleInterface::centerText("Total: " + to_string(currentPlayer->getScore()));
    cout << "\n\n";
      //victory fanfare
    for(int i = 0; i < 3; i++) {
        ConsoleInterface::beep(800 + i * 100, 200);
        ConsoleInterface::sleep(100);
    }
    //check if this is a new high score
    if(currentPlayer->getScore() > currentPlayer->getHighScore()) {
        ConsoleInterface::setYellow();
        ConsoleInterface::centerText("* NEW HIGH SCORE! *");
        cout << "\n\n";
        currentPlayer->setHighScore(currentPlayer->getScore());
    }

    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("Press any key to continue...");
    ConsoleInterface::setWhite();
    _getch();
}
