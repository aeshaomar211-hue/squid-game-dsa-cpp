#ifndef PLAYERS_H_INCLUDED
#define PLAYERS_H_INCLUDED

#include <string>
using namespace std;
// Player class manages player data including name, scores, and elimination status
// Private members can only be directly accessed within the Player class
class Player{
private:
    // Player's username
    string name;
    // Current game score
    int score;
    // All-time best score
    int highScore;
    // Whether player is eliminated in current game
    bool eliminated;

public:
    // Constructor - creates a new player with given name
    Player(const string& name);

    // Adds points to player's current score
    void addScore(int points);

    // Marks player as eliminated (game over)
    void eliminate();

    // Resets player for a new game (clears score and elimination status)
    void reset();

    // Getter functions - provide read-only access to private data
    // Returns player's name
    string getName() const;
    // Returns current score
    int getScore() const;
    // Returns all-time high score
    int getHighScore() const;
    // Returns elimination status

    bool isEliminated() const;

    // Updates player's high score if new score is higher
    void setHighScore(int hs);
};

#endif // PLAYERS_H_INCLUDED
