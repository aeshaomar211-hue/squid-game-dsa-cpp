#include "Question.h"
using namespace std;
//constructor, assembling a question package
//the ticking time bomb
Question::Question(const string& q , const vector<string>& opt , int correct , int time):question(q) , options(opt) , correctAnswer(correct) , timeLimit(time){}
//returns true for success false for elimination
bool Question::checkAnswer(int answer) const{
     //compare players guess with the secret answer
    return answer == correctAnswer;
}
//how much timelimit each player have
int Question::getTimeLimit() const {
    return timeLimit;
}
//player who wasnt paying attention ask for question
string Question::getQuestion() const {
    return question;
}
//player deciding between educated guess and wild guess
vector<string> Question::getOptions() {
    //returns all the possible answers
    return options;
}
