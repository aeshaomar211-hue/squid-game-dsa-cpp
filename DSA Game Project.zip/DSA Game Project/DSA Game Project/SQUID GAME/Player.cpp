#include "Player.h"
using namespace std;
//Players are constructor and are perametarized constructors using staing name as there perameter
Player::Player(const string& name) : name(name), score(0), highScore(0), eliminated(false) {}
//In add function player scores are added on bassis of duration and correct annserwers
//and point got added into scores  and comaparison is happening with higher scorer at
//the same time with comparison operator.
void Player::addScore(int points) {
    score += points;
    if(score > highScore) highScore = score;
}
//when player clicks any key during red zone or Time exceeds its limit the elemination function
//will be true and player will get eliminated
void Player::eliminate() {
    eliminated = true;
}
//Scores will be reset to zero when player statrt a new game after elimination or is playing !st  time
//But Hight score will remain same and elimination function in new game will become false
void Player::reset() {
    score = 0;
    eliminated = false;
}
//These are the functions associated with player as get name to register or log in and
//scores of player ,got eliminated or not and what are the highest scores  and if players
//scores  are greater than earlier higher scores then his scores will be adddd
//and recorded as next highest scores
string Player::getName() const {
    return name;
}
int Player::getScore() const {
    return score;
}
int Player::getHighScore() const {
    return highScore;
}
bool Player::isEliminated() const {
    return eliminated;
}
void Player::setHighScore(int hs) {
    highScore = hs;
}
