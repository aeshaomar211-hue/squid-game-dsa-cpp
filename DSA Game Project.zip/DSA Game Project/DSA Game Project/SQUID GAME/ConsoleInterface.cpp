#include "ConsoleInterface.h"
#include <iostream>
#include <string>
//This libabry is used to fetch characters and to check if keys are pressed  or not and respons are created
//creating according to that keys but only on Windows
#include <conio.h>
using namespace std;
/*In this function we are setting red colour to text through 12 colour code in windows  console ,and
getting remote control specifically for outputs */
void ConsoleInterface::setRed(){
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole , 12);
}
/*In this function we are setting Green colour to text through 10 colour code in windows  console ,and
getting remote control specifically for outputs */
    void ConsoleInterface::setGreen() {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 10);
}
/*In this function we are setting light blue colour to text through 11 colour code in windows  console ,and
getting remote control specifically for outputs */
void ConsoleInterface::setBlue() {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 11);
}
/*In this function we are setting Yellow colour to text through 14 colour code in windows  console ,and
getting remote control specifically for outputs */
void ConsoleInterface::setYellow() {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 14);
}
/*In this function we are setting whirte colour to text through 7 colour code in windows  console ,and
getting remote control specifically for outputs */
void ConsoleInterface::setWhite() {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 7);
}
/*Ceteralized the context on console for better visualization and include spacing of
better readability between printing these strings  accorgding to length of strings and handel console
for accessig outputs */
void ConsoleInterface::centerText(const string& text) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(hConsole, &csbi);
    int width = csbi.srWindow.Right - csbi.srWindow.Left + 1;
    int spaces = (width - text.length()) / 2;
    if(spaces > 0) cout << string(spaces, ' ');
    cout << text << endl;
}
/*windowas run cls commands for Running codes on Windows and clear Console screen  as this is platform dependent
program and it coukd be run only on Windows*/

void ConsoleInterface::clearScreen() {
    system("cls");
}
/* Ttle are set throuhjgh title command of Windows  and Converting
strings to C style strings  */
void ConsoleInterface::setTitle(const string& title) {
    system(("title " + title).c_str());
}
//In this function we are setting sizes and columns are showing width and rows are showing lenghth
void ConsoleInterface::setConsoleSize(int cols, int rows) {
    system(("mode con: cols=" + to_string(cols) + " lines=" + to_string(rows)).c_str());
}
//this function is trying to mentain to pause the concole Application till any key is pressed
void ConsoleInterface::waitForKeyPress() {
    system("pause > nul");
}
//when keys are pressed Interface immedaiately fetch  or read the key to response in result of actions
char ConsoleInterface::getKeyPress() {
    return _getch();
}
//bool function to chek either any key is pressed or not or respond correctly or not  and use
//real time inputs
bool ConsoleInterface::keyPressed() {
    return _kbhit() != 0;
}
//Beep Function is showing through perameters depending on frequency and duratios
void ConsoleInterface::beep(int frequency, int duration) {
    Beep(frequency, duration);
}
void ConsoleInterface::sleep(int milliseconds) {
    Sleep(milliseconds);
}

