//If header if not define degine it and if its is definned then include it in file
#ifndef CONSOLEINTERFACE_H_INCLUDED
#define CONSOLEINTERFACE_H_INCLUDED
//Preventing windows from maximum and minimum definitions
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
//Including windows file as this code is specifically for windows Apis headers
#include<windows.h>
#include <string>
using namespace std;
class ConsoleInterface{
public:
    //Pulically setting coding colours as  Red for red zone duration and Green for Playing zzone Blue for normal positions
    static void setRed();
    static void setGreen();
    static void setBlue();
    static void setYellow();
    static void setWhite();
    //Centeralized the texr for better font and visibility and clear the screen
    static void centerText(const string& text);
    static void clearScreen();
    //Setting titles and console size and press keys functions and get keys functions  and beeps for better interface
    //These functions are static as they show you dont needf to creat  object all these function belongs to class itself
    //and it in a shared tool and no personal data is required
    static void setTitle(const string& title);
    static void setConsoleSize(int cols , int rows);
    static void waitForKeyPress();
    static char getKeyPress();
    static bool keyPressed();
    static void beep(int frequency , int duration);
    static void sleep(int millieseconds);
};

#endif // CONSOLEINTERFACE_H_INCLUDED
