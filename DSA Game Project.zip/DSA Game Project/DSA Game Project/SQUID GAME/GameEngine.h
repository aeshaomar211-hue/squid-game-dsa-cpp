#ifndef GAMEENGINE_H_INCLUDED
#define GAMEENGINE_H_INCLUDED
//ours game building block
//to handle dsa questions
#include "Question.h"
//the people playing our game
#include "Player.h"
//the fancy display stuff
#include "ConsoleInterface.h"
//for queuing up questions
#include <queue>
//for tracking eliminations
#include <stack>
//for storing players by username
#include <map>
//because words are important
#include <string>
//for storing all our questions
#include <vector>
//so we don't have to type std:: evey two seconds
using namespace std;

class GameEngine{
private:
    //game state variables
    //queue of questions for the current game
    queue<Question*> questionQueue;
    //stack of recent elimnations
    stack<pair<string,string>> eliminations;
    //all registered players stored by username
    map<string , Player*>players;

    Player* currentPlayer;
    bool signal;
    //how many questions answered in current game
    int questionsAnswered;
    //total questions per game
    int totalQuestions;
    //when did the current signal
    time_t signalStart;
    //how long it lasts
    int signalDuration;
    bool gameRunning;
    //the master list of all DSA questions
    vector<Question*> allQuestions;
    //private mehods
    void loadQuestions();
    //void loadPlayers();
    //void savePlayers();
    //show the game menu after login,,,start game,see rules,logout
    void showGameMenu();
    //display the game rules
    void showInstructions();
    //the leaderboard
    void showLeaderboard();
    //register a new player
    void registerPlayer();
    //login existing player
    void loginPlayer();
    //play one round of red light/green light
    void startGame();
    void playRound();
    //eliminate a player
    void eliminate(const string& reason);
    void showWinScreen();
//PUBLIC METHODS
public:
    //Constructor
    GameEngine();
    ~GameEngine();

    //the main gae loop
    void run();
    void showMainMenu();

};


#endif
