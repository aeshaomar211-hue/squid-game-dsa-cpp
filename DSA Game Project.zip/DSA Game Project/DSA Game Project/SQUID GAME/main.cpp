#include "GameEngine.h"
#include "ConsoleInterface.h"
#include<iostream>

using namespace std;

//program: Squid Game DSA Challenge


/**
 * Application Entry Point
 *
 * Execution Flow:
 *   1. Environment Setup
 *   2. Visual Presentation
 *   3. User Interaction
 *   4. Game Execution
 *   5. Graceful Termination
 */
int main() {
    //purpose: Prepare console for optimal game presentation
    //set window title for taskbar identification
    ConsoleInterface::setTitle("Squid Game DSA Challenge");
    //define fixed window dimensions for consistent UI layout
    //apply color theme: black background,bright whit text
    system("color 0F");
    //purpose:resent branded welcome screen
    //ensure clean visual slate
    ConsoleInterface::clearScreen();
    //strategic vertical centering
    cout << "\n\n\n\n\n";
    //display primary application branding
    ConsoleInterface::setGreen();
    ConsoleInterface::centerText("=========================================");
    ConsoleInterface::centerText("     SQUID GAME DSA CHALLENGE     ");
    ConsoleInterface::centerText("=========================================");
    //visual separation between banner and interctive element
    cout << "\n\n\n";
    //all to action with attentiongrabbing color
    ConsoleInterface::setYellow();
    ConsoleInterface::centerText("Press any key to start the game...");
    //confirm user rediness before game launch
    //reset to neutral text color before blocking input
    ConsoleInterface::setWhite();
    //pause execution until user interaction
    ConsoleInterface::getKeyPress();
    //instantiate and execute main game functionality
    GameEngine game;
    //run() method
    game.run();

    //return control to operating system cleanly
    //gameEngine destructor automaticaly invoked for resource cleanup
    return 0;
}
