#ifndef QUESTION_H_INCLUDED
#define QUESTION_H_INCLUDED
#include <string>
#include <vector>
using namespace std;
//class question
class Question{
private:
    //member variables
    //text of question presened to player
    string question;
    //collection of possible answers
    vector<string> options;
    //index (0-based) of correct option inoptions vector
    int correctAnswer;
    //allowed response time in seconds
    int timeLimit;
//Constructor for Question objects
public:
    Question(const string& q , const vector<string>& opt , int correct , int time=15);
    //answer validation method
    bool checkAnswer(int answer) const;
    //time limit acessor
    int getTimeLimit() const;
    //question text accessor
    string getQuestion() const;
    //answer options accessor
    vector<string> getOptions();

};

#endif
